This folder contains all the captured evidence for the tab or application detected.
The saving of the capture is in /camera_monitoring/save_capture.php.