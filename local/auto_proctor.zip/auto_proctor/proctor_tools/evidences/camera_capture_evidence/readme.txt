This folder contains all the captured evidence for the detected suspicious movement.
The saving of the capture is in /camera_monitoring/save_cam_capture.php.