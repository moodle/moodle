<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_wellbeing';
$plugin->version   = 2026021013;
$plugin->requires  = 2022041901;
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = '0.1';
