<?php
defined('MOODLE_INTERNAL') || die();

function local_wellbeing_extend_navigation_course(
    navigation_node $navigation,
    stdClass $course,
    context_course $context
) {

    global $PAGE;

    // Only course view page
    if (strpos($PAGE->pagetype, 'course-view') !== 0) {
        return;
    }

    // ✅ Only show if enabled in custom field
    if (!\local_wellbeing\manager::is_enabled($course->id)) {
        return;
    }

    $url = new moodle_url('/local/wellbeing/dashboard.php', [
        'id' => $course->id
    ]);

    $buttonhtml = '
        <div id="wellbeing-btn-wrapper" style="text-align:left;margin:20px;">
            <a class="btn btn-primary"
               href="'.$url.'">
               Wellbeing Dashboard
            </a>
        </div>
    ';

    $PAGE->requires->js_init_code("
        document.addEventListener('DOMContentLoaded', function() {
            if (!document.getElementById('wellbeing-btn-wrapper')) {
                var container = document.querySelector('#region-main');
                if (container) {
                    container.insertAdjacentHTML('afterbegin', ".json_encode($buttonhtml).");
                }
            }
        });
    ");
}