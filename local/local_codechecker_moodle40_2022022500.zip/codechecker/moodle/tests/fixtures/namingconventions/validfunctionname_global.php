<?php
defined('MOODLE_INTERNAL') || die(); // Make this always the 1st line in all CS fixtures.

function __construct() {
    echo 'hi';
}

function jsonSerialize() {
    echi 'hi';
}
