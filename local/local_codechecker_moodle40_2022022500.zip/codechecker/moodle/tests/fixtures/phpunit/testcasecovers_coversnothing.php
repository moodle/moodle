<?php
defined('MOODLE_INTERNAL') || die(); // Make this always the 1st line in all CS fixtures.

// Wrong @coversNothing.

/**
 * @coversNothing wrong
 */
class coversnothing_test extends base_test {
    /**
     * @coversNothing wrong
     */
    public function test_something() {
        // Nothing to test.
    }
}
