<?php
defined('MOODLE_INTERNAL') || die(); // Make this always the 1st line in all CS fixtures.

// Incorrect fixtures go here.

// A class named _test and extending something is inspected.
class something_test extends base_test {
    public function test_something() {
        // Nothing to test.
    }
}
