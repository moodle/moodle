<?php
namespace local_codechecker\level2\level3;
defined("MOODLE_INTERNAL") || die(); // Make this always the 1st line in all CS fixtures.

/**
 * Correct class, just the namespace level2 and level3 don't correspond with the expected location.
 */
class testcasenames_unexpected_level2ns extends local_codechecker_testcase {
    public function test_something() {
    }
}
