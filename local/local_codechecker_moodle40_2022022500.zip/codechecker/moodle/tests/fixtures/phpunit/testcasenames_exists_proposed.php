<?php
defined("MOODLE_INTERNAL") || die(); // Make this always the 1st line in all CS fixtures.

/**
 * Correct class but with name not matching the file name.
 */
class testcasenames_exists_proposed extends \local_codechecker_testcase {
    public function test_something() {
    }
}
