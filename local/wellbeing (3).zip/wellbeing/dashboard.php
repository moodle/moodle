<?php

require('../../config.php');

use local_wellbeing\service\analysis_service;
use core\chart_series;
use core\chart_bar;
use core\chart_pie;
use core\chart_line;

// --------------------------------------------------
$courseid = required_param('id', PARAM_INT);

$course = get_course($courseid);
$context = context_course::instance($courseid);

require_login($course);

$PAGE->set_url('/local/wellbeing/dashboard.php', ['id' => $courseid]);
$PAGE->set_context($context);
$PAGE->set_title('Wellbeing Dashboard');
$PAGE->set_heading($course->fullname);
$PAGE->set_pagelayout('report');

// --------------------------------------------------
// Get Aggregated Metrics
// --------------------------------------------------

if (has_capability('moodle/course:update', $context)) {
    $totals = analysis_service::get_course_aggregated_metrics($courseid);
    $isstudent = false;
} else {
    $totals = analysis_service::get_user_course_metrics($courseid, $USER->id);
    $isstudent = true;
}

echo $OUTPUT->header();
echo $OUTPUT->heading('Student Wellbeing Overview');

if (empty($totals)) {
    echo $OUTPUT->notification('No wellbeing data available yet.', 'info');
    echo $OUTPUT->footer();
    exit;
}

// --------------------------------------------------
// Prepare Data
// --------------------------------------------------

$labels = array_keys($totals);
$values = array_values($totals);
$totalresponses = array_sum($values);

$percentages = [];

foreach ($totals as $emotion => $count) {
    if ($totalresponses > 0) {
        $percentages[$emotion] = round(($count / $totalresponses) * 100);
    } else {
        $percentages[$emotion] = 0;
    }
}

$labels = array_keys($percentages);
$values = array_values($percentages);

// Emotional weight mapping
$weights = [
    'depressed' => 0,
    'sad' => 25,
    'neutral' => 50,
    'happy' => 75,
    'very_happy' => 100
];

$weightedtotal = 0;
$totalresponses = 0;

foreach ($totals as $emotion => $count) {

    $key = strtolower(trim($emotion));

    if (isset($weights[$key])) {
        $weightedtotal += $count * $weights[$key];
        $totalresponses += $count;
    }
}

if ($totalresponses > 0) {
    $overallscore = round($weightedtotal / $totalresponses);
} else {
    $overallscore = 0;
}
$percentage = max(0, min(100, $overallscore));

// --------------------------------------------------
// SMILEY + COLOR LOGIC
// --------------------------------------------------

if ($percentage < 20) {
    $emoji = "😟";
    $color = "#dc3545";
} elseif ($percentage < 40) {
    $emoji = "😕";
    $color = "#fd7e14";
} elseif ($percentage < 60) {
    $emoji = "😐";
    $color = "#ffc107";
} elseif ($percentage < 80) {
    $emoji = "🙂";
    $color = "#20c997";
} else {
    $emoji = "😄";
    $color = "#28a745";
}

// --------------------------------------------------
// STUDENT DASHBOARD ENHANCEMENT
// --------------------------------------------------

if ($isstudent) {

    echo html_writer::start_div('card p-4 mb-5 shadow-sm text-center');

    echo html_writer::tag('h3', 'Overall Well-Being Trend Analysis');

    // Circular Gauge
    echo html_writer::start_div('', [
        'style' => "
            position: relative;
            width: 200px;
            height: 200px;
            margin: 25px auto;
            border-radius: 50%;
            background: conic-gradient($color {$percentage}%, #e9ecef {$percentage}%);
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:60px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        "
    ]);

    echo $emoji;
    echo html_writer::end_div();

    echo html_writer::tag('h4', $percentage . '% Overall Wellbeing');

    if ($percentage < 40) {
        echo html_writer::tag('p', 'Your wellbeing is currently low. Focus on self-care and balance 💙');
    } elseif ($percentage < 70) {
        echo html_writer::tag('p', 'You are maintaining steady wellbeing. Keep building healthy habits 🌱');
    } else {
        echo html_writer::tag('p', 'Excellent emotional balance. You are thriving! 🌟');
    }

    // Insight Box
    $highestemotion = array_keys($totals, max($totals))[0];
    $lowestemotion  = array_keys($totals, min($totals))[0];

    echo html_writer::start_div('alert alert-light mt-4 text-left');
    echo "<strong>Trend Insight:</strong><br>";
    echo "• Strongest emotional factor: <strong>" . ucfirst($highestemotion) . "</strong><br>";
    echo "• Lowest emotional factor: <strong>" . ucfirst($lowestemotion) . "</strong><br>";
    echo "• Emotional balance index: <strong>$percentage%</strong>";
    echo html_writer::end_div();

    echo html_writer::end_div();

    // --------------------------------------------------
    // Line Trend Chart
    // --------------------------------------------------

   
}

// --------------------------------------------------
// Bar Chart
// --------------------------------------------------

$barchart = new chart_bar();
$barchart->set_title('Aggregated Emotional Metrics');

$series = new chart_series('Emotion Score', $values);
$barchart->add_series($series);
$barchart->set_labels($labels);

// --------------------------------------------------
// Pie Chart
// --------------------------------------------------

$piechart = new chart_pie();
$piechart->set_title('Emotion Distribution');
$piechart->add_series(new chart_series('', $values));
$piechart->set_labels($labels);

// --------------------------------------------------
// Render Charts
// --------------------------------------------------
$PAGE->requires->js_init_code("
    const style = document.createElement('style');
    style.innerHTML = `
        .chart-table,
        .chart-data-table,
        .core-chart-table,
        .chart-data,
        a[data-region=\"chart-table-toggle\"],
        a[data-action=\"toggle-chart-data\"] {
            display: none !important;
        }
    `;
    document.head.appendChild(style);
");

echo html_writer::start_div('row mt-4');

echo html_writer::start_div('col-md-6');
echo $OUTPUT->render($barchart);
echo html_writer::end_div();

echo html_writer::start_div('col-md-6');
echo $OUTPUT->render($piechart);
echo html_writer::end_div();

echo html_writer::end_div();

// --------------------------------------------------
// Data Table
// --------------------------------------------------

echo html_writer::start_div('mt-5');
echo html_writer::tag('h4', 'Detailed Breakdown');
echo html_writer::start_div('card shadow-sm p-4 mb-4');
echo html_writer::start_tag('table', ['class' => 'table table-striped']);
echo html_writer::start_tag('thead');
echo html_writer::start_tag('tr');
echo html_writer::tag('th', 'Emotion');
echo html_writer::tag('th', 'Total Score');
echo html_writer::end_tag('tr');
echo html_writer::end_tag('thead');

echo html_writer::start_tag('tbody');

foreach ($percentages as $emotion => $percent) {

    $cleanname = ucwords(str_replace('_', ' ', $emotion));

    // Subtle muted color system
 switch ($emotion) {

    case 'very_happy':
        $color = '#1f9d78'; // balanced teal-green
        break;

    case 'happy':
        $color = '#38a169'; // fresh but not neon green
        break;

    case 'neutral':
        $color = '#718096'; // modern slate grey-blue
        break;

    case 'sad':
        $color = '#dd6b20'; // soft amber (not harsh orange)
        break;

    case 'depressed':
        $color = '#c53030'; // controlled deep red
        break;

    default:
        $color = '#6c757d';
}

    echo html_writer::start_tag('tr', [
        'style' => 'border-bottom:1px solid #f1f3f5;'
    ]);

    // Emotion Name
    echo html_writer::tag(
        'td',
        '<span style="font-size:14px;color:#495057;">' . $cleanname . '</span>',
        ['style' => 'vertical-align:middle;width:200px;padding:10px 5px;']
    );

    // Progress Bar
    echo html_writer::start_tag('td', ['style' => 'padding:10px 5px;']);

    echo '
    <div style="
        background:#e9ecef;
        border-radius:6px;
        height:8px;
        overflow:hidden;
    ">
        <div style="
            width:' . $percent . '%;
            background:' . $color . ';
            height:100%;
        ">
        </div>
    </div>
    <div style="
        font-size:12px;
        color:#6c757d;
        margin-top:4px;
        text-align:right;
    ">
        ' . $percent . '%
    </div>
    ';

    echo html_writer::end_tag('td');

    echo html_writer::end_tag('tr');
}

echo html_writer::end_tag('tbody');
echo html_writer::end_tag('table');
echo html_writer::end_div();

echo $OUTPUT->footer();