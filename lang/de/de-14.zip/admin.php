<?PHP // $Id$ 
      // admin.php - created with Moodle 1.2 Beta +++ (2004031300)


$string['cachetext'] = 'Dauer der G�ltigkeit f�r Cache';
$string['filteruploadedfiles'] = 'Filter f�r hochgeladene Dateien';
$string['upgradelogs'] = 'F�r die vollst�ndige Funktionsf�higkeit m�ssen die alten Log-Daten aktualisiert werden. <a href=\"$a\">More information</a>';
$string['upgradelogsinfo'] = 'Die Art und Weise in der Log-Daten gespeichert werden wurde ver�ndert. Damit Sie Ihre alten Log-Daten mit den Einzelaktivit�ten einsehen k�nnen, m�ssen die alten Log-Daten aktualisiert werden. Je nachdem wie viele Daten auf Ihrer Seite gespeichert sind, kann dieser Vorgang eine l�ngere Zeit beanspruchen (u.U. mehrere Stunden). Der Vorgang beansprucht die Datenbank bei umfangreichen Seiten stark. Wenn Sie den Vorgang einmal gestartet haben, m�ssen Sie ihn ohne Unterbrechung abschlie�en lassen. Das Browserfenster darf nicht geschlossen und die Internetverbindung nicht unterbrochen werden in dieser Zeit. Der Zugriff auf Ihre Seite durch andere Anwender ist dadurch nicht beeintr�chtigt. <br /><br>Wollen Sie nun Ihre Log-Daten aktualisieren?';
$string['upgradinglogs'] = 'Log-Daten aktualisieren';

?>
