<?PHP // $Id$ 
      // block_course_summary.php - created with Moodle 1.4 aiming-for-beta-soon (2004082200)


$string['blockname'] = 'Kurszusammenfassung';
$string['siteinfo'] = 'Seiteninformation';

?>
