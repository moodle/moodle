<?PHP // $Id$ 
      // enrol_paypal.php - created with Moodle 1.4 aiming-for-beta-soon (2004082200)


$string['business'] = 'E-Mail Adresse Ihres gesch�ftlichen Paypal-Accounts';
$string['description'] = 'Das Paypal-Modul erm�glicht es Ihnen, Kurse anzulegen, f�r die Geb�hren erhoben werden. Wenn die Kursgeb�hren auf \'0\' gesetzt werden, werden die Teilnehmer/innen nicht aufgefordert vor dem Kurszugang zu bezahlen.<br>Es kann eine Geb�hrenvoreinstellung f�r alle Kurse vorgenommen werden. Die Einstellungen f�r den einzelnen Kurs �berschreibt die Voreinstellung.';
$string['enrolname'] = 'Paypal';
$string['sendpaymentbutton'] = 'Bezahlung �ber das Bezahlsystem Paypal';

?>
