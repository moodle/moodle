<?PHP // $Id$ 
      // multilang.php - created with Moodle 1.2 alpha (2004022200)


$string['filtername'] = 'Mehrsprachiger Inhalt';

?>
