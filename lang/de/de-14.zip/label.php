<?PHP // $Id$ 
      // label.php - created with Moodle 1.2 development (2004020300)


$string['labeltext'] = 'Text der Einf�hrung';
$string['modulename'] = 'Einf�hrung';
$string['modulenameplural'] = 'Einf�hrung';

?>
