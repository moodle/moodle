<?PHP // $Id$ 
      // book.php - created with Moodle 1.4 development (2004062600)


$string['addafter'] = 'Ein neues Kapitel hinzuf�gen';
$string['chapterscount'] = 'Kapitel';
$string['chaptertitle'] = 'Titel des Kapitels';
$string['confchapterdelete'] = 'Wollen Sie dieses Kapitel wirklich l�schen?';
$string['content'] = 'Inhalt';
$string['faq'] = 'Buch FAQ';
$string['modulename'] = 'Buch';
$string['modulenameplural'] = 'B�cher';
$string['navnext'] = 'N�chste';
$string['navprev'] = 'Vorherige';
$string['numbering'] = 'Kapitelnummerierung';
$string['numbering0'] = 'Keine';
$string['numbering1'] = 'Nummern';
$string['numbering2'] = 'Aufz�hlungspunkte';
$string['numbering3'] = 'Einr�ckung';
$string['printbook'] = 'Gesamtes Buch drucken';
$string['printchapter'] = 'Dieses Kapitel drucken';
$string['printdate'] = 'Datum';
$string['printedby'] = 'Gedruckt von';
$string['subchapter'] = 'Unterkapitel';
$string['toc'] = 'Inhaltsverzeichnis';
$string['tocwidth'] = 'W�hlen Sie die Breite des Inhaltsverzeichnisses f�r alle B�cher aus.';
$string['top'] = 'Oben';

?>
