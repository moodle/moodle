<?PHP // $Id$ 
      // enrol_database.php - created with Moodle 1.4 aiming-for-beta-soon (2004082200)


$string['dbhost'] = 'Name des Datenbank Servers';
$string['dbname'] = 'Die spezielle Datenbank, die genutzt werden soll';
$string['dbpass'] = 'Passwort f�r den Zugang zum Server';
$string['dbtable'] = 'Die Tabelle in dieser Datenbank';
$string['dbtype'] = 'Servertyp der Datenbank';
$string['dbuser'] = 'Benutzername f�r den Zugang zum Server';
$string['description'] = 'Sie k�nnen eine externe Datenbank (fast jeder Art benutzen), um den Zugang zu Moodle zu erm�glichen. Es wird vorausgesetzt, dass die Datenbank die Felder Kurs-ID und Benutzer-ID enth�lt. Diese werden gepr�ft gegen die Felder des Kurses und des Benutzers im Moodle System.';
$string['enrolname'] = 'Externe Datenbank';
$string['localcoursefield'] = 'Die Bezeichnung f�r das Feld aus der Moodle  Kurstabelle, welches f�r den Vergleich mit der externen Datenbank genutzt werden soll.';
$string['localuserfield'] = 'Die Bezeichnung f�r das Feld aus der Moodle Usertabelle, welches f�r den Vergleich mit der externen Datenbank genutzt werden soll.';
$string['remotecoursefield'] = 'Das Feld in der externen Datenbank, in dem die Kurs-ID f�r des Moodle-Systems zu finden ist.';
$string['remoteuserfield'] = 'Das Feld in der externen Datenbank, indem die Benutzer-ID des Moodle-Systems zu finden ist.';

?>
