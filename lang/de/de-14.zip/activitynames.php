<?PHP // $Id$ 
      // activitynames.php - created with Moodle 1.3 (2004052500)


$string['filtername'] = 'Automatisches Verlinken der Bezeichnungen von Aktivit�ten';

?>
