<?PHP // $Id$ 

$string['modulename'] = 'Event';
$string['modulenameplural'] = 'Events';


?>
