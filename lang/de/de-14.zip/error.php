<?PHP // $Id$ 
      // error.php - created with Moodle 1.4 aiming-for-beta-soon (2004082200)


$string['coursegroupunknown'] = 'Es wurde kein Kurs f�r Gruppe $a festgelegt';
$string['erroronline'] = 'Fehler in Zeile $a';
$string['fieldrequired'] = '\"$a\" ist eine Pflichtfeld';
$string['filenotfound'] = 'Entschuldigung, die angeforderte Datei wurde nicht gefunden.';
$string['groupalready'] = 'Teilnehmer/in geh�rt bereits zur Gruppe $a';
$string['groupunknown'] = 'Die Gruppe $a geh�rt nicht zum ausgew�hlten Kurs';
$string['invalidfieldname'] = '\"$a\" ist ein ung�ltiger Feldname';
$string['missingfield'] = 'Feld \"$a\" fehlt';
$string['modulerequirementsnotmet'] = 'Modul \"$a->modulename\" ($a->moduleversion) konnte nicht installiert werden. Es erfordert eine aktuellere Version von Moodle (Sie verwenden zur Zeit $a->currentmoodle, ben�tigt wird $a->requiremoodle).';
$string['notavailable'] = 'Dies ist zur Zeit nicht verf�gbar.';
$string['restricteduser'] = 'Sorry, Sie sind gegenw�rtig nicht zu dieser Aktion berechtigt.';
$string['unknowncourse'] = 'Unbekannter Kursname \"$a\"';
$string['usernotaddederror'] = 'Nutzer \"$a\" wurde nicht hinzugef�gt - unbekannter Fehler';
$string['usernotaddedregistered'] = 'Nutzer \"$a\" wurde nicht hinzugef�gt - er/sie war bereits registriert';
$string['usernotavailable'] = 'Sie k�nnen die Details f�r diese/n Nutzer/in nicht einsehen';

?>
