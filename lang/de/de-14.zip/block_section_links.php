<?PHP // $Id$ 
      // block_section_links.php - created with Moodle 1.3 (2004052500)


$string['blockname'] = 'Blocknamen';
$string['jumptocurrenttopic'] = 'Sprung zum jetzigen Themenblock';
$string['jumptocurrentweek'] = 'Sprung zu dieser Woche';
$string['topics'] = 'Themen';
$string['weeks'] = 'Wochen';

?>
