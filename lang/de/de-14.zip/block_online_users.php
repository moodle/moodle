<?PHP // $Id$ 
      // block_online_users.php - created with Moodle 1.3 development (2004041800)


$string['blockname'] = 'Onlinenutzer';
$string['configtimetosee'] = 'Dauer (in Minuten), die ben�tigt wird, um einen Nutzer als zur Zeit online, zu erkennen';
$string['periodnminutes'] = 'Dauer $a in Minuten';

?>
