<?PHP // $Id$ 
      // choice.php - created with Moodle 1.4 aiming-for-beta-soon (2004082200)


$string['allowupdate'] = 'Abstimmung kann aktualisiert werden';
$string['answered'] = 'Beantwortet';
$string['choice'] = 'Abstimmung  $a';
$string['choiceclose'] = 'Bis';
$string['choicename'] = 'Abstimmung';
$string['choiceopen'] = 'Offen';
$string['choicetext'] = 'Beschreibung der Abstimmung';
$string['havetologin'] = 'Sie m�ssen sich erst anmelden, bevor Sie sich an der Abstimmung beteiligen k�nnen.';
$string['modulename'] = 'Abstimmung';
$string['modulenameplural'] = 'Abstimmungen';
$string['mustchooseone'] = 'Sie m�ssen zuerst eine Antwort ausw�hlen bevor Sie speichern. Es wurde noch nicht gespeichert.';
$string['notanswered'] = 'Noch nicht beantwortet';
$string['notopenyet'] = 'Sorry, diese Aktivit�t ist erst ab $a verf�gbar.';
$string['privacy'] = 'Ergebnis nicht ver�ffentlichen';
$string['publish'] = 'Ergebnisse ver�ffentlichen';
$string['publishafteranswer'] = 'Ergebnisse den anderen Teilnehmer/inen nach der Abstimmung anzeigen';
$string['publishafterclose'] = 'Ergebnisse anderen Teilnehmer/innen erst anzeigen, nachdem die Abstimmung abgeschlossen ist';
$string['publishalways'] = 'Ergebnisse der anderen Teilnehmer/innen immer zeigen';
$string['publishanonymous'] = 'Anonyme Ergebnisse ver�ffentlichen, Namen der Teilnehmer nicht zeigen';
$string['publishnames'] = 'Ergebnisse vollst�ndig ver�ffentlichen, Namen und deren Wahl anzeigen';
$string['publishnot'] = 'Keine Ergebnisse ver�ffentlichen';
$string['responses'] = 'Antworten ';
$string['responsesto'] = 'Antworten zu  $a';
$string['savemychoice'] = 'Meine Abstimmung speichern';
$string['showunanswered'] = 'Zeige Spalte f�r Unbeantwortete';
$string['timerestrict'] = 'Antworten nur in dieser Periode anzeigen';
$string['viewallresponses'] = 'Zeige $a Antworten';

?>
