<?PHP // $Id$ 
      // journal.php - created with Moodle 1.2 development (2004020300)


$string['alwaysopen'] = 'Immer offen';
$string['blankentry'] = 'Leerer Eintrag';
$string['daysavailable'] = 'Tage verf�gbar';
$string['editingended'] = 'Bearbeitungszeitraum ist abgelaufen';
$string['editingends'] = 'Bearbeitungszeitraum endet';
$string['entries'] = 'Eintr�ge';
$string['feedbackupdated'] = 'Mitteilung f�r Eintrag $a aktualisiert';
$string['journalmail'] = '$a->Trainer/in hat einen Kommentar zu Ihrem  Journal \'$a->Journal\' abgegeben. Sie k�nnen dieses angeh�ngt an Ihr  Journal sehen:

$a->url';
$string['journalmailhtml'] = '$a->Trainer/in hat einen Kommentar zu Ihrem  <i>->Journal </i>\' abgegeben<br /><br /> Sie k�nnen diesen angeh�ngt an Ihr <a href=\"$a->url\"> Journal</a> sehen.';
$string['journalname'] = 'Name des Journals';
$string['journalquestion'] = 'Journal-Frage';
$string['journalrating1'] = 'nicht zufriedenstellend';
$string['journalrating2'] = 'zufriedenstellend';
$string['journalrating3'] = 'hervorragend';
$string['modulename'] = 'Journal';
$string['modulenameplural'] = 'Journale';
$string['newjournalentries'] = 'Neue Journal-Eintr�ge';
$string['noentry'] = 'Kein Eintrag';
$string['noratinggiven'] = 'Keine Beurteilung abgegeben';
$string['notopenuntil'] = 'Diese Journal wird geschlossen sein bis';
$string['notstarted'] = 'Sie haben mit Ihrem Journal noch nicht begonnen';
$string['overallrating'] = 'Allgemeine Beurteilung';
$string['rate'] = 'Beurteilung';
$string['saveallfeedback'] = 'Alle meine Mitteilungen speichern';
$string['startoredit'] = 'Journal-Eintrag beginnen oder bearbeiten';
$string['viewallentries'] = 'Zeige $a Journal-Eintr�ge';

?>
