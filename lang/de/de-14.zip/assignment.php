<?PHP // $Id$ 
      // assignment.php - created with Moodle 1.2 development (2004020300)


$string['allowresubmit'] = 'Erneutes Einreichen erlauben';
$string['assignmentdetails'] = 'Aufgabendetails';
$string['assignmentmail'] = '$a->Trainer/in hat einen Kommentar zu Ihrer eingereichten Aufgabe \'$a->assignment\' verfasst.

Sie finden diesen im Anhang Ihrer abgegebenen Aufgabe:

$a->url';
$string['assignmentmailhtml'] = '$a->Trainer/in hat einen Kommentar zu Ihrer abgegebenen Aufgabe verfasst.</i>\'<br /><br />
Sie finden diesen im Anhang Ihrer 
<a href=\"$a->url\">eingereichten Aufgabe</a>:.';
$string['assignmentname'] = 'Aufgabenname';
$string['assignmenttype'] = 'Aufgabentyp';
$string['configmaxbytes'] = 'Voreingestellte maximale Gr��e f�r alle Einstellungen auf dieser Seite';
$string['description'] = 'Beschreibung ';
$string['duedate'] = 'Abgabedatum';
$string['duedateno'] = 'keine f�lliges Datum';
$string['early'] = '$a fr�h';
$string['existingfiledeleted'] = 'Die vorhandene Datei wurde gel�scht: $a';
$string['failedupdatefeedback'] = 'Keine Aktualisierung der R�ckmeldung f�r Benutzer $a';
$string['feedback'] = 'R�ckmeldung';
$string['feedbackupdated'] = 'R�ckmeldung aktualisiert f�r $a Teilnehmer/innen';
$string['late'] = '$a sp�t ';
$string['maximumgrade'] = 'H�chste Bewertung ';
$string['maximumsize'] = 'Maximale Gr��e';
$string['modulename'] = 'Aufgabe';
$string['modulenameplural'] = 'Aufgaben';
$string['newsubmissions'] = 'Aufgaben eingereicht';
$string['notgradedyet'] = 'Noch nicht bewertet';
$string['notsubmittedyet'] = 'Noch nichts eingereicht';
$string['overwritewarning'] = 'Hinweis: erneutes hochladen ERSETZT Ihren gegenw�rtigen Eintrag ';
$string['saveallfeedback'] = 'Alle meine R�ckmeldungen speichern';
$string['submissionfeedback'] = 'R�ckmeldung zu den eingereichten Aufgaben';
$string['submissions'] = 'Eingereichte Aufgaben';
$string['submitassignment'] = 'Tragen Sie Ihre Aufgabe unter Verwendung dieses Formulars ein';
$string['submitted'] = 'Eingereicht';
$string['typeoffline'] = 'Offline Aktivit�t ';
$string['typeuploadsingle'] = 'Eine einzige Datei hochladen';
$string['uploadbadname'] = 'Dieser Dateiname enth�lt unzul�ssige Zeichen und kann nicht hochgeladen werden.';
$string['uploadedfiles'] = 'hochgeladene Dateien';
$string['uploaderror'] = 'Beim Hochladen der Datei trat ein Fehler auf';
$string['uploadfailnoupdate'] = 'Die Datei wurde korrekt hochgeladen, aber Ihr Eintrag kann nicht aktualisiert werden!';
$string['uploadfiletoobig'] = 'Entschuldigung, aber diese Datei ist zu gro� (Die Begrenzung ist $a Bytes)';
$string['uploadnofilefound'] = 'Es wurde keine Datei gefunden. Sind Sie sicher, dass Sie eine f�r das Hochladen ausgew�hlt haben?';
$string['uploadnotregistered'] = '\'$a\' wurde korrekt hochgeladen, aber der Eintrag wurde nicht registriert!';
$string['uploadsuccess'] = '\'$a\' wurde erfolgreich hochgeladen';
$string['viewfeedback'] = 'Aufgabenbewertung und R�ckmeldung anzeigen ';
$string['viewsubmissions'] = 'Zeige $a eingereichte Aufgaben ';
$string['yoursubmission'] = 'Ihre eingereichten Aufgaben';

?>
