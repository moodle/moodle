<?PHP // $Id$ 
      // mediaplugin.php - created with Moodle 1.2 alpha (2004022200)


$string['filtername'] = 'Multimedia Plugin';

?>
