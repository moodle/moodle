<?PHP // $Id$ 
      // webquest.php - created with Moodle 1.2 development (2003120700)


$string['modulename'] = 'Webquest';
$string['modulenameplural'] = 'Webquests';

?>
