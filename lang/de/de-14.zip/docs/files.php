<?php // $Id$
      // Namen der Dokumentationsdateien
      // Dateien mit einer "-" Definition werden als Abschnitte verwandt

$string['-about'] = "�ber Moodle";
$string['intro.html'] = "Einf�hrung";
$string['background.html'] = "Hintergrund";
$string['philosophy.html'] = "Philosophie";
$string['licence.html'] = "Lizenz";
$string['features.html'] = "Features";
$string['release.html'] = "Versionen";
$string['future.html'] = "Zukunft";
$string['credits.html'] = "Danke sch�n";

$string['-installation'] = "Verwaltung";
$string['install.html'] = "Installation";
$string['faq.html'] = "FAQ";
$string['installamp.html'] = "Apache, MySQL, PHP installieren";
$string['upgrade.html'] = "Upgrading";

$string['-usage'] = "Moodle nutzen";
$string['teacher.html'] = "Dozentenhandbuch";
$string['other.html'] = "Andere Dokumente";

$string['-development'] = "Programmentwicklung";
$string['developer.html'] = "Entwicklerhandbuch";
$string['coding.html'] = "Code Richtlinien";
$string['cvs.html'] = "CVS benutzen";


?>