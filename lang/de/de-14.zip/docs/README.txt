
Wenn Sie diese Dokumentation in eine andere Sprache �bersetzen wollen,
empfehle ich Ihnen:

 1) die englischen Versionen der Dateien nicht in dieses Verzeichnis zu kopieren.
    Wenn das Programm im von Ih en gew�hlten Sprachverzeichnis keine �bersetzung dieser
    Datei findet, nutzt es automatisch die englische Fassung.

 2) �bersetzen Sie in der folgenden Reihenfolge (beginnen Sie mit den wichtigsten Dateien):

    DIE WICHTIGSTEN DATEIEN
    |-------------------
    |
    |   - files.php
    |   - install.html
    |   - upgrade.html
    |
    |  -----------------
    |
    |   - teacher.html
    |   - module_files.txt
    |
    |  -----------------
    |
    |   - intro.html
    |   - features.html
    |   - release.html
    |
    |  -----------------
    |
    |   - developer.html
    |   - cvs.html
    |   - future.html
    |
    |  -----------------
    |
    |   - license.html
    |   - credits.html
    |
    |-------------------
    WENIGER WICHTIGE DATEIEN