<?PHP // $Id$ 
      // enrol_internal.php - created with Moodle 1.4 aiming-for-beta-soon (2004082200)


$string['description'] = 'Dies ist die Standardmethode f�r die Registrierung. Es gibt zwei verschiedene M�glichkeiten Teilnehmer/innen den Zugang zu einem Kurs zu erm�glichen.
<ul>
<li>Ein/e Trainer/in oder Adminstrator/in registriert die Teilnehmer/innen manuell �ber den Link im Adnministrationsmen� des Kurses.</li>
<li>F�r den Kurs wird ein Passwort vergeben, welcher als Zugangsschl�ssel bezeichnet wird. Jede/r Teilnehmer/in, die/der diesen Zugangsschl�ssel kennt, kann sich in den Kurs einschreiben.</li>
</ul>';
$string['enrolname'] = 'Interne Registrierung';

?>
