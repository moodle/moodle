Die deutsche �bersetzung wird betreut von

<a href="mailto:andre.krueger@wirab50.de">Andre Kr�ger</a> und <a href="mailto:rh@dialoge.net">Ralf Hilgenstock</a>.<br>
<br>
Die Diskussion erfolgt im <a href="http://moodle.org/course/view.php?id=18">deutschen Forum von Moodle</a>.
