<?PHP // $Id$ 
      // pix.php - created with Moodle 1.2 development (2004020300)


$string['angry'] = '�rgerlich';
$string['approve'] = 'anerkennend';
$string['biggrin'] = 'Breites Grinsen';
$string['blackeye'] = 'Schwarzauge';
$string['blush'] = 'err�tend';
$string['clown'] = 'Clown';
$string['cool'] = 'cool';
$string['dead'] = 'tot';
$string['evil'] = '�bel';
$string['kiss'] = 'Kuss';
$string['mixed'] = 'gemischt';
$string['sad'] = 'traurig';
$string['shy'] = 'sch�chtern';
$string['sleepy'] = 'schl�frig';
$string['smiley'] = 'l�chelnd';
$string['surprise'] = '�berrascht';
$string['thoughtful'] = 'gedankenverloren';
$string['tongueout'] = 'herausgestreckte Zunge';
$string['wideeyes'] = 'weitaufgerissene Augen';
$string['wink'] = 'winken';

?>
