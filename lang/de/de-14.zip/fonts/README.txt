Schriftarten
------------

Dieses Verzeichnis enth�lt Schrifarten,
die verwendet werden, wenn Bilder mit Text erstellt werden.
Die einzige, die z.Zt. verwendet wird, ist default.ttf.

Wenn eine Sprache nicht �ber die Schriftart verf�gt, 
wird stattdessen /lang/en/fonts/default.ttf verwendet.  

Multibyte-Strings m�ssen decodiert werden, 
weil die Truetype Routinen ISO-Fonts oder Unicode Zeichenketten erwarten.  
Wenn eine Datei lang_decode.php existiert, die eine Funktion
lang_decode() enth�lt, wird sie bei jeder Zeichenkette verwendet.