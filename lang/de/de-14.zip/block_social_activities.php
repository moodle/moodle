<?PHP // $Id$ 
      // block_social_activities.php - created with Moodle 1.3 development (2004041800)


$string['blockname'] = 'Gemeinschaftsaktivit�ten';

?>
