<?PHP // $Id$ 
      // block_course_list.php - created with Moodle 1.4 development (2004052800)


$string['allcourses'] = 'Administrator/innen sehen alle Kurse';
$string['blockname'] = 'Kurs�bersicht';
$string['configadminview'] = ' ';
$string['owncourses'] = 'Administrator/innen sehen nur eigene Kurse';

?>
