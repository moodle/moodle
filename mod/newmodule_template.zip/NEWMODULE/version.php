<?PHP // $Id: version.php,v 1.7 2002/08/28 13:20:20 martin Exp $

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of NEWMODULE
///  This fragment is called by moodle_needs_upgrading() and /admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$module->version  = 2002090700;   // The (date) version of this module
$module->cron     = 0;            // How often should cron check this module (seconds)?

function NEWMODULE_upgrade($oldversion) {
/// This function does anything necessary to upgrade
/// older versions to match current functionality

    global $CFG;

    if ($oldversion < 2002090700) {

       # Do something ...

    }

    return true;
}

?>
