function init() {
    document.querySelectorAll(".field-custom-element").forEach(element => {
        element.innerHTML = "New value";
    });
}
window.onload = init;