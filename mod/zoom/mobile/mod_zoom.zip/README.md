# mma-mod-zoom
mobile app version of zoom module

@package    mod_zoom
@author     Robert Quinlivan <rquinlivan@gmail.com>