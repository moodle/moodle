# mma-qtype-gapfill
mobile app version of gapfill question type
