<?php

$plugin->version = 2014121200;
$plugin->component = 'foo_bar';
$plugin->requires = 9999999900;
